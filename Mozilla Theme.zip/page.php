<?php
/**
 * mozilla_berlin
 */
get_header(); ?>

<div class="container page-content">
    <?php get_template_part( 'assets/partials/page-content' ); ?>
</div>


<?php get_footer();