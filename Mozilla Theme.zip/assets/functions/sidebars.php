<?php
/*
 * Register Sidebar
 *
 */
//add_action( 'widgets_init', 'mozilla_berlin_widgets_init' );
//function mozilla_berlin_widgets_init() {
//    register_sidebar( array(
//        'name' => __( 'Main Sidebar', 'mozilla_berlin' ),
//        'id' => 'sidebar-1',
//        'description' => __( 'Widgets in this area will be shown on all posts and pages.', 'mozilla_berlin' ),
//        'before_widget' => '<section id="%1$s" class="widget %2$s">',
//		'after_widget'  => '</section>',
//		'before_title'  => '<h3 class="widget-title">',
//		'after_title'   => '</h3>',
//    ) );
//}
