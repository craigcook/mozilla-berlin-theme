<?php
/**
 * mozilla_berlin
 */
?>

<?php comment_form();