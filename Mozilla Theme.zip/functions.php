<?php
/*
 * functions.php
 * 
 */

 require_once( __DIR__ . '/assets/functions/error_report.php');
 require_once( __DIR__ . '/assets/functions/setup.php');
 require_once( __DIR__ . '/assets/functions/disables.php');
 require_once( __DIR__ . '/assets/functions/scripts.php');
 require_once( __DIR__ . '/assets/functions/sidebars.php');
 require_once( __DIR__ . '/assets/functions/functions.php');
 require_once( __DIR__ . '/assets/functions/numericnav.php');
 require_once( __DIR__ . '/assets/functions/acf_include.php');
 require_once( __DIR__ . '/assets/functions/acf_template.php');
 require_once( __DIR__ . '/assets/functions/custom_posttypes.php');
 require_once( __DIR__ . '/assets/functions/twitter.php');